#!/bin/bash
# Change to the project directory (adjust if your project is elsewhere)
cd /home/rrh1441/scraper_trigger || exit
# Activate the virtual environment
source /home/rrh1441/scraper_trigger/venv/bin/activate
# Run the spider (using the full path to the scrapy executable)
~/scraper_trigger/venv/bin/scrapy crawl AncSpider >> ~/scraper_trigger/cron.log 2>&1
